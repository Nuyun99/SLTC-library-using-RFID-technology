
public class Main {

	public static void main(String[] args) {
		
		adminpanel panel1 = new adminpanel();
		//new searchbook();
	}

}
